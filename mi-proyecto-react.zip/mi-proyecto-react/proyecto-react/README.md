# proyecto-react

# Explorador de Películas 🎬

Una aplicación en React para buscar películas, ver detalles y sugerir nuevas películas.  

## Cómo correr el proyecto

1. Clonar el repositorio:
   ```bash
   git clone https://github.com/tuusuario/explorador-peliculas.git
