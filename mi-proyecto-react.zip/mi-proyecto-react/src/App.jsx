import React from "react";
import { Routes, Route, Link } from "react-router-dom";
import Buscador from "./componentes/Buscador.jsx";
import ListaPeliculas from "./componentes/ListaPeliculas.jsx";
import DetallePelicula from "./componentes/DetallePelicula.jsx";
import FormularioSugerencia from "./componentes/FormularioSugerencia.jsx";

function App() {
  return (
    <div style={{ padding: "20px" }}>
      <h1>Explorador de Películas 🎬</h1>
      <nav style={{ marginBottom: "20px" }}>
        <Link to="/" style={{ marginRight: "10px" }}>Inicio</Link>
        <Link to="/sugerencia">Sugerir Película</Link>
      </nav>
      <Routes>
        <Route path="/" element={
          <>
            <Buscador />
            <ListaPeliculas />
          </>
        } />
        <Route path="/pelicula/:id" element={<DetallePelicula />} />
        <Route path="/sugerencia" element={<FormularioSugerencia />} />
      </Routes>
    </div>
  );
}

export default App;
