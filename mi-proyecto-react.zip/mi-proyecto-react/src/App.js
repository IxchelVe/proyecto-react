import { useState } from 'react'
import Buscador from './componentes/Buscador.jsx'
import ListaPeliculas from './componentes/ListaPeliculas.jsx'
import DetallePelicula from './componentes/detallePelicula'
import FormularioSugerencia from './componentes/formularioSugerencia'
import { useContext } from 'react'
import { PeliculasContexto } from './contexto/peliculasContexto'

function App() {
  const [pagina, setPagina] = useState("inicio")
  const { seleccionada } = useContext(PeliculasContexto)

  return (
    <div style={{ padding: "20px" }}>
      <h1>🎥 Explorador de Películas</h1>
      <nav>
        <button onClick={() => setPagina("inicio")}>Inicio</button>
        <button onClick={() => setPagina("sugerencias")}>Sugerir</button>
      </nav>

      {pagina === "inicio" && !seleccionada && (
        <>
          <Buscador />
          <ListaPeliculas />
        </>
      )}

      {seleccionada && <DetallePelicula />}

      {pagina === "sugerencias" && <FormularioSugerencia />}
    </div>
  )
}

export default App;
