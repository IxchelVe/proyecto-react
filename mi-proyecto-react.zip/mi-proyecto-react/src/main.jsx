import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App.jsx";
import { PeliculasProvider } from "./contexto/PeliculasContexto.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <PeliculasProvider>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </PeliculasProvider>
  </React.StrictMode>
);
