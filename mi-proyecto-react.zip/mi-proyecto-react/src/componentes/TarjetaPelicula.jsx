import React from "react";
import { Link } from "react-router-dom";

function TarjetaPelicula({ peli }) {
  return (
    <div style={{ border: "1px solid #ccc", padding: "10px", margin: "10px", width: "200px" }}>
      <img src={peli.Poster !== "N/A" ? peli.Poster : "https://via.placeholder.com/200"} alt={peli.Title} style={{ width: "100%" }} />
      <h3>{peli.Title}</h3>
      <p>{peli.Year}</p>
      <Link to={`/pelicula/${peli.imdbID}`}>Ver más</Link>
    </div>
  );
}

export default TarjetaPelicula;
