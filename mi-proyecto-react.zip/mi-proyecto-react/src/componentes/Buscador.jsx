import React, { useState, useContext } from "react";
import { PeliculasContexto } from "../contexto/PeliculasContexto.jsx";
import axios from "axios";

function Buscador() {
  const [texto, setTexto] = useState("");
  const { setPeliculas } = useContext(PeliculasContexto);
  const apiKey = "512229e4"; 

  const buscar = async () => {
    if (!texto) return;
    try {
      const respuesta = await axios.get(`https://www.omdbapi.com/?apikey=${apiKey}&s=${texto}`);
      if (respuesta.data.Search) {
        setPeliculas(respuesta.data.Search);
      } else {
        setPeliculas([]);
        alert("No se encontraron películas 😢");
      }
    } catch (error) {
      console.error("Error buscando películas:", error);
      setPeliculas([]);
    }
  };

  return (
    <div style={{ margin: "20px 0" }}>
      <input
        type="text"
        value={texto}
        onChange={(e) => setTexto(e.target.value)}
        placeholder="Buscar película..."
      />
      <button onClick={buscar} style={{ marginLeft: "10px" }}>Buscar</button>
    </div>
  );
}

export default Buscador;
