import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";

function DetallePelicula() {
  const { id } = useParams();
  const [detalle, setDetalle] = useState(null);
  const apiKey = "TU_API_KEY_AQUI"; // <--- pon tu API Key aquí también

  useEffect(() => {
    const obtenerDetalle = async () => {
      try {
        const respuesta = await axios.get(`https://www.omdbapi.com/?apikey=${apiKey}&i=${id}&plot=full`);
        setDetalle(respuesta.data);
      } catch (error) {
        console.error("Error cargando detalle:", error);
      }
    };
    obtenerDetalle();
  }, [id]);

  if (!detalle) return <p>Cargando detalle...</p>;

  return (
    <div style={{ padding: "20px" }}>
      <h2>{detalle.Title} ({detalle.Year})</h2>
      <img src={detalle.Poster !== "N/A" ? detalle.Poster : "https://via.placeholder.com/300"} alt={detalle.Title} style={{ width: "300px" }} />
      <p>{detalle.Plot}</p>
      <p><strong>Género:</strong> {detalle.Genre}</p>
      <p><strong>Director:</strong> {detalle.Director}</p>
      <p><strong>Actores:</strong> {detalle.Actors}</p>
    </div>
  );
}

export default DetallePelicula;
