import React, { useState } from "react";

function FormularioSugerencia() {
  const [nombre, setNombre] = useState("");
  const [pelicula, setPelicula] = useState("");

  const enviar = (e) => {
    e.preventDefault();
    alert(`Gracias ${nombre}, sugeriste la película: ${pelicula}`);
    setNombre("");
    setPelicula("");
  };

  return (
    <form onSubmit={enviar} style={{ margin: "20px 0" }}>
      <input type="text" placeholder="Tu nombre" value={nombre} onChange={(e) => setNombre(e.target.value)} required />
      <input type="text" placeholder="Película que quieres sugerir" value={pelicula} onChange={(e) => setPelicula(e.target.value)} required style={{ marginLeft: "10px" }} />
      <button type="submit" style={{ marginLeft: "10px" }}>Enviar</button>
    </form>
  );
}

export default FormularioSugerencia;
