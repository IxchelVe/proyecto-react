import React, { useContext } from "react";
import { PeliculasContexto } from "../contexto/PeliculasContexto.jsx";
import TarjetaPelicula from "./TarjetaPelicula.jsx";

function ListaPeliculas() {
  const { peliculas } = useContext(PeliculasContexto);

  if (!peliculas || peliculas.length === 0) {
    return <p>No hay películas para mostrar 😢</p>;
  }

  return (
    <div style={{ display: "flex", flexWrap: "wrap" }}>
      {peliculas.map((peli) => (
        <TarjetaPelicula key={peli.imdbID} peli={peli} />
      ))}
    </div>
  );
}

export default ListaPeliculas;
