import React, { createContext, useState } from "react";

export const PeliculasContexto = createContext();

export function PeliculasProvider({ children }) {
  const [peliculas, setPeliculas] = useState([]);

  return (
    <PeliculasContexto.Provider value={{ peliculas, setPeliculas }}>
      {children}
    </PeliculasContexto.Provider>
  );
}
